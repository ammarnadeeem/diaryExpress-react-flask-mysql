import React, { Component } from "react";

class AboutUs extends Component {
  state = {};
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-6 mt-5 mx-auto">
            <h1 className="h3 mb-3 font-weight-normal">About Us</h1>
            <body>
              DiaryExpress has some expertise in giving completely adjustable
              diaries.
            </body>
            <br />
            <body>
              These are one of the profoundly requested items by foundations and
              associations over the world for organization outings, classes,
              office or individual use to make notes on customary premise
              updates of date to date.
            </body>
            <br />
            <body>
              With an expect to fulfill our customers in the most ideal way,
              DiaryExpress is effectively innovating the contribution to the
              clients while these administrations are rendered utilizing the
              cutting edge innovation under the course of industry specialists.
            </body>
            <br />
            <body>
              We are offering these administrations at pocket-accommodating
              costs to our important benefactors inside the guaranteed edge of
              time. Our offered run diaries is accessible in various colors,
              designs and examples to meet the specific needs of the customers.
            </body>
            <br />
            <body>
              DiaryExpress guarantees to give wide variety of journals to
              fulfill the necessities of each market section and suit
              everybody's pocket that causes clients to browse wide assortment
              of diaries and get it redid. Products that we offer are redone
              according to your need.
            </body>
          </div>
        </div>
      </div>
    );
  }
}

export default AboutUs;
